// Exemple : message dans la console
console.log("JS chargé avec succès !");

// Ajouter au panier (plus tard)