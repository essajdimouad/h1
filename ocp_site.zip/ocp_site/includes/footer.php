  </main>
  <footer class="footer">
    <div class="container">
      &copy; <?= date("Y") ?> OCP Maroc. Tous droits réservés.
    </div>
  </footer>
</body>
</html>
